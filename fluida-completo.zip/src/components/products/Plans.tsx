// Caminho sugerido: ./src/components/products/Plans.tsx
import { Card, CardContent } from "@/components/ui/card"

const plans = [
  { name: "Starter", price: "Grátis", features: ["1 roteiro por dia", "Planner limitado"] },
  { name: "Pro", price: "R$49/mês", features: ["10 roteiros/dia", "IA avançada", "Planner completo", "PDFs ilimitados"] },
  { name: "Studio", price: "R$149/mês", features: ["Roteiros ilimitados", "Equipe", "Mídia IA", "Consultoria IA"] },
]

export default function Plans() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4">
      {plans.map((plan) => (
        <Card key={plan.name}>
          <CardContent className="p-4 space-y-2">
            <h3 className="text-xl font-semibold">{plan.name}</h3>
            <div className="text-muted-foreground">{plan.price}</div>
            <ul className="text-sm mt-2 list-disc list-inside">
              {plan.features.map((f, i) => (
                <li key={i}>{f}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}