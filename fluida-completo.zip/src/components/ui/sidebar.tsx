
"use client"

// Exportar tudo do novo módulo
export * from "./sidebar/index"
