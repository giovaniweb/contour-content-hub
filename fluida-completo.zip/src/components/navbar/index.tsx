
// First import the Navbar component
import { Navbar as NavbarComponent } from "./Navbar";

// Then export it
export const Navbar = NavbarComponent;
export default NavbarComponent;
