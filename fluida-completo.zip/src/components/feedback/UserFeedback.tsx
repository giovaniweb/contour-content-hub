// Caminho sugerido: ./src/components/feedback/UserFeedback.tsx
import { useState } from "react"

export default function UserFeedback() {
  const [rating, setRating] = useState<number | null>(null)
  const [comment, setComment] = useState("")

  return (
    <div className="p-6 max-w-md mx-auto">
      <h2 className="text-xl font-semibold mb-2">O que achou da experiência?</h2>
      <div className="flex gap-2 mb-4">
        {[1, 2, 3, 4, 5].map((r) => (
          <button
            key={r}
            onClick={() => setRating(r)}
            className={`p-2 text-lg rounded-full ${rating === r ? 'bg-purple-600 text-white' : 'bg-gray-200'}`}
          >
            {r}⭐
          </button>
        ))}
      </div>
      <textarea
        className="w-full p-2 border rounded mb-4"
        placeholder="Deixe um comentário..."
        value={comment}
        onChange={(e) => setComment(e.target.value)}
      />
      <button className="bg-purple-600 text-white px-4 py-2 rounded hover:opacity-90">Enviar</button>
    </div>
  )
}