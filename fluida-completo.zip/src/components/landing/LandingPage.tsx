// Caminho sugerido: ./src/components/landing/LandingPage.tsx
export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 to-black text-white flex flex-col items-center justify-center text-center p-10">
      <h1 className="text-5xl font-bold mb-4">Bem-vindo ao Fluida ✨</h1>
      <p className="text-lg text-gray-300 mb-8">A plataforma de inteligência criativa para clínicas estéticas</p>
      <a href="/login" className="bg-white text-purple-900 font-semibold py-2 px-6 rounded-full shadow-lg hover:scale-105 transition">Começar agora</a>
    </div>
  )
}